﻿print('Current weather: Sunny')
