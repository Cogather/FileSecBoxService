﻿---
name: weather_skill
description: 一个用于验证接口的天气查询测试技能
---
此处是技能的具体说明文档。
